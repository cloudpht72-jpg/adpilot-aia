# AdPilot AI — Deploy-ready Demo

A responsive agency command-center demo with a FastAPI backend, SQLite demo database, simulated AI-agent endpoints, campaign records, optimization recommendations, and an audit log.

## Safety / scope
- This build is **DEMO MODE**.
- It does not connect to Meta, publish ads, change live budgets, or spend money.
- Agent outputs are deterministic demo logic, not a connected LLM.
- Never put Meta access tokens or client secrets into this demo.
- Production use needs authentication, tenant isolation, encrypted OAuth token storage, Meta App Review/permissions as applicable, consent, tracking validation, monitoring, and human-approved budget policies.

## Deploy on Render (recommended)
1. Upload this project to a GitHub repository.
2. Sign in to Render and choose **New → Blueprint**.
3. Connect the repository containing `render.yaml`.
4. Review the service and persistent disk, then deploy.
5. Open the generated `onrender.com` URL.
6. Test `/api/health` and `/docs`.

The Blueprint uses a persistent disk for the SQLite demo database. The first boot seeds sample clients and campaigns.

## Deploy with Docker
```bash
docker build -t adpilot-ai-demo .
docker run --rm -p 8000:8000 -e DEMO_MODE=true adpilot-ai-demo
```
Then open http://localhost:8000

## Run locally
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## API routes
- `GET /api/health`
- `GET /api/overview`
- `GET /api/clients`
- `GET /api/campaigns`
- `GET /api/agents`
- `POST /api/agents/run`
- `POST /api/optimize`
- `POST /api/campaigns` (creates a local draft only)
- `GET /api/decisions`
- `GET /api/settings`
- `GET /docs` (interactive API docs)

## Demo credentials
No login is configured because this is a public demo. Do not use real client data or expose private information.

## Before any real advertising
A separate production implementation is required. It should include:
1. User authentication and MFA.
2. Strict multi-tenant authorization and PostgreSQL row-level security.
3. Meta OAuth with least-privilege permissions and secure token storage.
4. Client-specific authorization and explicit approved daily/lifetime budgets.
5. Campaign creation in draft/review state by default.
6. Tracking/attribution checks and policy compliance checks.
7. Approval workflow, action logs, kill switch, alerts, and rollback procedures.
8. Load, security, and integration testing.

No AI system can guarantee sales or growth. Performance depends on the offer, market, creative, tracking, audience, landing page, and budget.
