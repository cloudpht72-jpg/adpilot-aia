from __future__ import annotations
import os, sqlite3, json, uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BASE = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("DATABASE_PATH", str(BASE.parent / "adpilot.db")))
DEMO_MODE = os.getenv("DEMO_MODE", "true").lower() == "true"
CURRENCY = os.getenv("DEFAULT_CURRENCY", "USD")

app = FastAPI(
    title="AdPilot AI Demo API",
    description="Multi-client autonomous marketing agency demo. All ad actions are simulated.",
    version="1.0.0",
)

def now():
    return datetime.now(timezone.utc).isoformat()

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS clients (
          id TEXT PRIMARY KEY, name TEXT NOT NULL, country TEXT NOT NULL,
          currency TEXT NOT NULL, daily_budget REAL NOT NULL,
          spend_today REAL NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'active'
        );
        CREATE TABLE IF NOT EXISTS campaigns (
          id TEXT PRIMARY KEY, client_id TEXT NOT NULL, name TEXT NOT NULL,
          objective TEXT NOT NULL, status TEXT NOT NULL, daily_budget REAL NOT NULL,
          spend REAL NOT NULL DEFAULT 0, impressions INTEGER NOT NULL DEFAULT 0,
          clicks INTEGER NOT NULL DEFAULT 0, leads INTEGER NOT NULL DEFAULT 0,
          purchases INTEGER NOT NULL DEFAULT 0, revenue REAL NOT NULL DEFAULT 0,
          FOREIGN KEY(client_id) REFERENCES clients(id)
        );
        CREATE TABLE IF NOT EXISTS decisions (
          id TEXT PRIMARY KEY, client_id TEXT NOT NULL, agent TEXT NOT NULL,
          action TEXT NOT NULL, detail TEXT NOT NULL, created_at TEXT NOT NULL
        );
        """)
        count = con.execute("SELECT COUNT(*) FROM clients").fetchone()[0]
        if count == 0:
            clients = [
              ("cl_001","Northstar Fitness","United States","USD",150.0,82.5,"active"),
              ("cl_002","Luna Skincare","United Kingdom","GBP",90.0,44.0,"active"),
              ("cl_003","Dhaka Home Store","Bangladesh","BDT",12000.0,6500.0,"active"),
            ]
            con.executemany("INSERT INTO clients VALUES (?,?,?,?,?,?,?)", clients)
            campaigns = [
              ("cp_001","cl_001","January Membership Leads","LEADS","active",100,62,24500,620,48,0,0),
              ("cp_002","cl_001","Fitness Trial Retargeting","SALES","active",50,20.5,8200,205,12,4,680),
              ("cp_003","cl_002","Glow Serum Prospecting","SALES","active",60,31,18300,410,18,6,510),
              ("cp_004","cl_002","Skincare UGC Test","LEADS","paused",30,13,6200,155,9,0,0),
              ("cp_005","cl_003","Home Organizer Sales","SALES","active",8000,4800,36000,920,0,22,78500),
            ]
            con.executemany("INSERT INTO campaigns VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", campaigns)

init_db()

def rowdict(row):
    return dict(row) if row else None

def log_decision(client_id: str, agent: str, action: str, detail: str):
    with db() as con:
        con.execute(
          "INSERT INTO decisions VALUES (?,?,?,?,?,?)",
          (str(uuid.uuid4()), client_id, agent, action, detail, now())
        )

class OptimizeRequest(BaseModel):
    client_id: str
    max_budget_increase_pct: float = Field(default=10, ge=0, le=20)
    apply_changes: bool = False

class CampaignCreate(BaseModel):
    client_id: str
    name: str = Field(min_length=3, max_length=100)
    objective: str = Field(default="LEADS", pattern="^(LEADS|SALES|TRAFFIC|AWARENESS)$")
    daily_budget: float = Field(gt=0)

@app.get("/api/health")
def health():
    return {"status":"ok","service":"AdPilot AI","mode":"DEMO" if DEMO_MODE else "INTEGRATION_READY","timestamp":now()}

@app.get("/api/overview")
def overview():
    with db() as con:
        clients = con.execute("SELECT * FROM clients ORDER BY name").fetchall()
        campaigns = con.execute("SELECT * FROM campaigns").fetchall()
    spend = sum(c["spend"] for c in campaigns)
    revenue = sum(c["revenue"] for c in campaigns)
    return {
      "clients": len(clients),
      "active_campaigns": sum(1 for c in campaigns if c["status"] == "active"),
      "spend": round(spend,2),
      "revenue": round(revenue,2),
      "roas": round(revenue/spend,2) if spend else 0,
      "mode": "DEMO — no real ads are being changed",
    }

@app.get("/api/clients")
def get_clients():
    with db() as con:
        return [rowdict(r) for r in con.execute("SELECT * FROM clients ORDER BY name")]

@app.get("/api/campaigns")
def get_campaigns(client_id: str | None = None):
    with db() as con:
        if client_id:
            rows = con.execute("SELECT * FROM campaigns WHERE client_id=? ORDER BY name",(client_id,)).fetchall()
        else:
            rows = con.execute("SELECT * FROM campaigns ORDER BY name").fetchall()
        return [rowdict(r) for r in rows]

@app.get("/api/agents")
def agents():
    return [
      {"name":"Market Research Agent","status":"ready","purpose":"Summarizes market, offer and competitor research (demo data)."},
      {"name":"Audience Strategy Agent","status":"ready","purpose":"Suggests country, audience and funnel strategy."},
      {"name":"Creative Agent","status":"ready","purpose":"Drafts ad angles, primary text and headlines."},
      {"name":"Campaign Manager Agent","status":"guarded","purpose":"Creates simulated campaign plans; live publishing is disabled."},
      {"name":"Optimization Agent","status":"ready","purpose":"Reviews simulated performance and proposes budget actions."},
      {"name":"Sales Intelligence Agent","status":"ready","purpose":"Analyzes leads, purchases, revenue and ROAS."},
      {"name":"Reporting Agent","status":"ready","purpose":"Creates client-friendly performance summaries."},
    ]

@app.post("/api/agents/run")
def run_agent(payload: dict[str, Any]):
    client_id = payload.get("client_id")
    agent = payload.get("agent", "Optimization Agent")
    task = payload.get("task", "Analyze campaign performance")
    if not client_id:
        raise HTTPException(400, "client_id is required")
    with db() as con:
        client = con.execute("SELECT * FROM clients WHERE id=?",(client_id,)).fetchone()
        campaigns = con.execute("SELECT * FROM campaigns WHERE client_id=?",(client_id,)).fetchall()
    if not client:
        raise HTTPException(404, "Client not found")
    spend = sum(c["spend"] for c in campaigns)
    revenue = sum(c["revenue"] for c in campaigns)
    leads = sum(c["leads"] for c in campaigns)
    purchases = sum(c["purchases"] for c in campaigns)
    roas = revenue/spend if spend else 0
    if "creative" in agent.lower():
        result = {
          "summary": f"Creative direction for {client['name']}: lead with the customer's desired outcome, show proof, make one clear offer, and use a direct CTA.",
          "recommendations":["Create 3 distinct hooks for the same offer.","Test short UGC-style video against a static proof-led creative.","Keep claims specific and substantiated."],
          "sample_primary_text": "Ready for a simpler way to reach your goal? Discover the offer and see what makes it different.",
          "sample_headline": "Your next step starts here"
        }
    elif "audience" in agent.lower() or "target" in agent.lower():
        result = {
          "summary": f"Audience strategy draft for {client['country']}.",
          "recommendations":["Start with a broad/Advantage-style test where eligible.","Separate warm retargeting from prospecting.","Use first-party customer data only with the required rights and consent."],
          "testing_plan":"Run 2–3 controlled audience hypotheses; compare cost per qualified result, not just CTR."
        }
    elif "sales" in agent.lower():
        result = {"summary":f"{leads} leads and {purchases} purchases recorded in demo data.",
          "recommendations":["Verify Pixel/Conversions API event quality.","Compare purchase value against spend.","Review lead-to-sale conversion, not lead volume alone."],
          "demo_roas":round(roas,2)}
    elif "research" in agent.lower():
        result = {"summary":f"Research brief for {client['name']} ({client['country']}).",
          "recommendations":["Clarify the core customer problem and unique value proposition.","Map 3 competitor messages and identify an underserved angle.","Validate demand and claims before launching ads."]}
    elif "report" in agent.lower():
        result = {"summary":f"{client['name']} demo report: spend {client['currency']} {spend:.2f}; revenue {client['currency']} {revenue:.2f}; ROAS {roas:.2f}x.",
          "recommendations":["Review conversion tracking before scaling.","Keep budget changes within the approved client cap."]}
    else:
        result = {"summary":f"Performance review for {client['name']}.",
          "metrics":{"spend":round(spend,2),"revenue":round(revenue,2),"roas":round(roas,2),"leads":leads,"purchases":purchases},
          "recommendations":["Check tracking and attribution first.","Prioritize campaigns with stable conversion volume.","Avoid scaling on one-day noise."],
          "proposed_action":"No live changes executed. Demo mode only."}
    log_decision(client_id, agent, task, json.dumps(result))
    return {"agent":agent,"client":client["name"],"task":task,"result":result,"execution":"SIMULATED — no Meta Ads API call made"}

@app.post("/api/optimize")
def optimize(req: OptimizeRequest):
    with db() as con:
        client = con.execute("SELECT * FROM clients WHERE id=?",(req.client_id,)).fetchone()
        campaigns = con.execute("SELECT * FROM campaigns WHERE client_id=?",(req.client_id,)).fetchall()
    if not client:
        raise HTTPException(404, "Client not found")
    active = [c for c in campaigns if c["status"] == "active"]
    suggestions = []
    for c in active:
        roas = c["revenue"]/c["spend"] if c["spend"] else 0
        if roas >= 2:
            suggestions.append({"campaign":c["name"],"recommendation":"Consider a cautious scale test","proposed_daily_budget":round(min(c["daily_budget"]*(1+req.max_budget_increase_pct/100), client["daily_budget"]),2),"reason":f"Demo ROAS {roas:.2f}x"})
        elif c["spend"] and c["leads"] == 0 and c["purchases"] == 0:
            suggestions.append({"campaign":c["name"],"recommendation":"Review creative, offer and tracking before spending more","proposed_daily_budget":c["daily_budget"],"reason":"No demo conversions recorded"})
        else:
            suggestions.append({"campaign":c["name"],"recommendation":"Continue monitoring; do not make a premature change","proposed_daily_budget":c["daily_budget"],"reason":f"Demo ROAS {roas:.2f}x"})
    result = {"client":client["name"],"client_daily_budget_cap":client["daily_budget"],"current_spend_today":client["spend_today"],"suggestions":suggestions,"changes_applied":False}
    if req.apply_changes:
        result["note"] = "Changes are intentionally not applied in this demo. Live publishing requires Meta authorization and an explicit production implementation."
    log_decision(req.client_id,"Optimization Agent","Generate optimization plan",json.dumps(result))
    return result

@app.post("/api/campaigns")
def create_campaign(req: CampaignCreate):
    with db() as con:
        client = con.execute("SELECT * FROM clients WHERE id=?",(req.client_id,)).fetchone()
        if not client:
            raise HTTPException(404,"Client not found")
        if req.daily_budget > client["daily_budget"]:
            raise HTTPException(400,"Campaign budget cannot exceed the client's approved daily budget cap.")
        cid = "cp_" + uuid.uuid4().hex[:8]
        con.execute("INSERT INTO campaigns (id,client_id,name,objective,status,daily_budget) VALUES (?,?,?,?,?,?)",
                    (cid,req.client_id,req.name,req.objective,"draft",req.daily_budget))
    log_decision(req.client_id,"Campaign Manager Agent","Create draft campaign",f"{req.name} ({req.objective})")
    return {"id":cid,"status":"draft","message":"Draft created in demo database. It has NOT been published to Meta."}

@app.get("/api/decisions")
def decisions():
    with db() as con:
        rows = con.execute("SELECT * FROM decisions ORDER BY created_at DESC LIMIT 50").fetchall()
        return [rowdict(r) for r in rows]

@app.get("/api/settings")
def settings():
    return {"demo_mode":DEMO_MODE,"live_ads_enabled":False,"currency_default":CURRENCY,
            "safety":"All ad publishing and spend-changing actions are disabled in this demo."}

@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")
